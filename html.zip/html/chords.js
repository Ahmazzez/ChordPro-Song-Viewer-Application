//AHMAD KANAAN 101276072
// Mapping of note names to semitones
const CHORD_MAP = {
  "C": 0, "C#": 1, "Db": 1, "D": 2, "D#": 3, "Eb": 3, "E": 4, "F": 5,
  "F#": 6, "Gb": 6, "G": 7, "G#": 8, "Ab": 8, "A": 9, "A#": 10, "Bb": 10, "B": 11
};

const SEMITONE_MAP = Object.entries(CHORD_MAP).reduce((map, [key, value]) => {
  if (!map[value]) map[value] = [];
  map[value].push(key);
  return map;
}, {});

// Store original chords in a dictionary for reference
let originalChords = new Map();
let currentTranspose = 0; // keeps track of how many semitones transposed

function parseChordProFormat(chordProLinesArray) {
  console.log("Parsing song data:", chordProLinesArray);

  let textDiv = document.getElementById("text-area");
  textDiv.innerHTML = ""; // Clear previous content
  originalChords.clear(); // reset stored chords
  currentTranspose = 0; // Reset transpose count

  for (let i = 0; i < chordProLinesArray.length; i++) {
    let line = chordProLinesArray[i].trim();
    if (!line) continue; // skip empty lines

    if (line.startsWith("{title:")) {
      let title = line.replace("{title:", "").replace("}", "").trim();
      textDiv.innerHTML += `<h1>${title}</h1>`;
      continue;
    }

    let formattedLyric = "";
    let formattedChords = "";
    let insideChord = false;
    let chordBuffer = "";
    let chordPositions = [];
    let lastPosition = 0;

    for (let j = 0; j < line.length; j++) {
      let char = line[j];

      if (char === "[") {
        insideChord = true;
        chordBuffer = "";
      } else if (char === "]") {
        insideChord = false;

        let lastWordStart = formattedLyric.lastIndexOf(" ", lastPosition);
        let chordPlacement = lastWordStart !== -1 ? lastWordStart + 1 : lastPosition;

        chordPositions.push({ chord: chordBuffer, position: chordPlacement });

        // Store the original chord mapping with its index
        originalChords.set(chordBuffer, chordBuffer);
      } else {
        if (insideChord) {
          chordBuffer += char;
        } else {
          formattedLyric += char;
          lastPosition = formattedLyric.length;
        }
      }
    }

    let chordLine = "";
    lastPosition = 0;

    for (let pos of chordPositions) {
      let spaceNeeded = pos.position - lastPosition;
      if (spaceNeeded > 0) {
        chordLine += " ".repeat(spaceNeeded);
      }
      chordLine += `<span class="chord chord-original" data-original="${pos.chord}">${pos.chord}</span>`;
      lastPosition = pos.position + pos.chord.length;
    }

    if (formattedLyric.trim() === "") {
      textDiv.innerHTML += `<pre class="chord">${chordLine}</pre>`;
    } else {
      textDiv.innerHTML += `<pre class="chord">${chordLine}</pre>`;
      textDiv.innerHTML += `<pre class="lyrics">${formattedLyric}</pre>`;
    }
  }
}

// transpose all chords up or down by the given number of steps
function transposeChords(steps) {
  currentTranspose += steps; // Update transpose state

  let chords = document.querySelectorAll(".chord");

  chords.forEach(chordSpan => {
    let originalChord = chordSpan.getAttribute("data-original"); // always get the original chord
    if (!originalChord) return;

    let transposedChord = transposeChord(originalChord, currentTranspose);
    chordSpan.textContent = transposedChord;

    // Change color based on whether it's back to original key
    chordSpan.className = `chord ${
      currentTranspose === 0 ? "chord-original" : "chord-transposed"
    }`;
  });
}

// Transpose a single chord
function transposeChord(chord, steps) {
  let match = chord.match(/^([A-Ga-g#b]+)(.*)$/);
  if (!match) return chord;

  let [_, root, suffix] = match;
  let transposedRoot = transposeRoot(root, steps);

  return transposedRoot + suffix;
}

// Adjust the root note semitone-wise
function transposeRoot(root, steps) {
  let semitone = CHORD_MAP[root];
  if (semitone === undefined) return root;

  let newSemitone = (semitone + steps + 12) % 12;
  let enharmonicChoices = SEMITONE_MAP[newSemitone];

  return enharmonicChoices.includes(root) ? root : enharmonicChoices[0];
}

// Reset to original key
function resetToOriginalKey() {
  currentTranspose = 0;
  let chords = document.querySelectorAll(".chord");

  chords.forEach(chordSpan => {
    let originalChord = chordSpan.getAttribute("data-original"); // Restore original chord
    if (!originalChord) return;

    chordSpan.textContent = originalChord;
    chordSpan.className = "chord chord-original"; // Restore green color
  });
}

// Event Listeners for Transposition
document.getElementById("transpose_up").addEventListener("click", () => transposeChords(1));
document.getElementById("transpose_down").addEventListener("click", () => transposeChords(-1));
document.getElementById("original_key").addEventListener("click", resetToOriginalKey);
